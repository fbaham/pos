<?php

class ControllerTemplate{

  public function ctr_template(){
    include "views/template.php";
  }

}
?>
