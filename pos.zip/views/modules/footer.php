<footer class="main-footer">
  <strong>Copyright &copy; 2018 <a href="https://fbcreativos.cl" target="_blank">FB Creativos</a></strong>
  Todos los derechos reservados
</footer>
